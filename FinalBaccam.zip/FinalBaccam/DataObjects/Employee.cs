﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    public class Employee : User
    {
        public string EmployeeID { get; set; }

        public string Password { get; set; }

        public Employee() 
        { }

        public Employee(User user)
        {
            this.FullName = user.FullName;
            this.PhoneNumber = user.PhoneNumber;
            this.Email = user.Email;
        }
    }
}
