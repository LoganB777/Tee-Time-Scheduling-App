﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    // Object made up off OpenTeeTime objects and User objects to keep
    // track of all tee times that have been booked by users
    public class BookedTeeTime : OpenTeeTime
    {
        public BookedTeeTime()
        {
        }

        public BookedTeeTime(User user)
        {
            User = user;
        }


        public User User { get; }
    }
}
