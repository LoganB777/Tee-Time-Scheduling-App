﻿using System;
using System.IO;

namespace DataObjects
{
    // User class is used accross the program to preform tasks.
    public class User
    {
        public User()
        {
        }

        public User(string fullName, string phoneNumber, string email)
        {
            FullName = fullName;
            PhoneNumber = phoneNumber;
            Email = email;
        }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }

        

    }
}
