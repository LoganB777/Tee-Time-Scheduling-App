﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    // The OpenTeeTime class is used to be viewed and selected by users. Once an
    // OpenTeeTime is selected by the user is passed to a BookedTeeTime object
    public class OpenTeeTime { 
        public DateTime DateTime { get; set; }

        public OpenTeeTime() { }

        public OpenTeeTime(DateTime dateTime)
        {
            DateTime = dateTime;
        }

        public override string ToString()
        {
            return DateTime.ToString("MM/dd/yyyy hh:mm:ss tt");
        }

        public int CompareTo(OpenTeeTime tt)
        {
            return DateTime.CompareTo(tt.DateTime);
        }
    }
}
