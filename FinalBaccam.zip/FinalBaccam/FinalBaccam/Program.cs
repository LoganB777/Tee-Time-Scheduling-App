﻿using LogicLayer;
using System;

namespace FinalBaccam
{
    class Program
    {
        static void Main(string[] args)
        {
            Helper helper = new Helper();
        }
    }
}
