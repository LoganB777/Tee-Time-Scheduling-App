﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class Validater
    {
        // Validates a full name by checking for at least two name parts and ensuring they are not 
        // numbers or special characters
        public bool ValidateFullName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
            {
                return false;
            }

            string[] nameParts = fullName.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (nameParts.Length < 2)
            {
                return false;
            }

            foreach (string namePart in nameParts)
            {
                if (namePart.Any(c => char.IsDigit(c) || (!char.IsLetter(c) && c != '.')))
                {
                    return false; 
                }
            }

            return true;
        }

        // Validates a phone number by ensuring it contains only digits and has a minimum length of 10
        public bool ValidatePhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                return false;
            }

            string strippedPhoneNumber = phoneNumber.Replace("-", "");

            if (!strippedPhoneNumber.All(char.IsDigit) || strippedPhoneNumber.Length <10)
            {
                return false;
            }

            return true; 
        }

        // Validates an email address using a regular expression pattern ensuring there is an @
        // character and a . character
        public bool ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return false;
            }

            string emailPattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            return Regex.IsMatch(email, emailPattern);
        }

    }
}
