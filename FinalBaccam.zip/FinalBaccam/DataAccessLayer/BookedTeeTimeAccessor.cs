﻿using DataObjects;
using Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DataAccessLayer
{
    public class BookedTeeTimeAccessor : BookedTeeTimeIF
    {

        OpenTeeTimeAccessor openTeeTimeAccessor = new OpenTeeTimeAccessor();
        UserAccessor userAccessor = new UserAccessor();
        LinkedList<BookedTeeTime> BookedTeeTimes = new LinkedList<BookedTeeTime>();

        // Method to load all of the data from the BookedTeeTimesQueue.txt fiile and
        // returns a linked list of BookedTeeTimes
        public LinkedList<BookedTeeTime> GetBookedTeeTimes(string BookedTeeTimesFilePath)
        {

            if (File.Exists(BookedTeeTimesFilePath))
            {
                string[] lines = File.ReadAllLines(BookedTeeTimesFilePath);
                if (lines.Length > 0)
                {
                    BookedTeeTimes.Clear();
                    foreach (string line in lines)
                    {
                        string[] data = line.Split(',');
                        if (data.Length == 4)
                        {
                            string fullName = data[0];
                            string phoneNumber = data[1];
                            string email = data[2];
                            DateTime dateTime = DateTime.ParseExact(data[3], "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture);
                            User user = new User(fullName, phoneNumber, email);
                            OpenTeeTime openTeeTime = new OpenTeeTime(dateTime);
                            BookedTeeTime bookedTeeTime = new BookedTeeTime(user);
                            bookedTeeTime.DateTime = dateTime;
                            BookedTeeTimes.AddLast(bookedTeeTime);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("There are currently no Booked Tee Times.");
                }
            }
            else
            {
                throw new FileNotFoundException("Booked Tee Times file does not exist.");
            }

            return BookedTeeTimes;
        }

        // Allows user selection of a booked tee time from the list displayed
        public BookedTeeTime SelectBookedTeeTime(string BookedTeeTimesFilePath)
        {
            try
            {
                BookedTeeTime selectedTeeTime = new BookedTeeTime();
                ViewBookedTeeTimes();
                Console.WriteLine("Select Booked Tee Time:");
                if (int.TryParse(Console.ReadLine(), out int teeTimeNum))
                {
                    if (teeTimeNum > 0 && teeTimeNum <= BookedTeeTimes.Count)
                    {
                        selectedTeeTime = BookedTeeTimes.ElementAt(teeTimeNum - 1);
                    }
                    else
                    {
                        Console.WriteLine("Invalid selection. Please enter a valid number.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter one of the provided numbers.");
                }
                return selectedTeeTime;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while selecting Booked Tee Time: " + ex.Message);
                return null;
            }
        }

        // Displays the booked tee times based on selected sorting order (earliest to latest or latest to earliest)
        public void ViewBookedTeeTimes()
        {
            string BookedTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/BookedTeeTimesQueue.txt";
            GetBookedTeeTimes(BookedTeeTimesFilePath);
            SortBookedTeeTimes(BookedTeeTimes);
            Console.WriteLine("\nChoose sorting order:");
            Console.WriteLine("1. Earliest to Latest");
            Console.WriteLine("2. Latest to Earliest");
            Console.Write("Select an option: ");

            if (int.TryParse(Console.ReadLine(), out int sortChoice))
            {
                if (sortChoice == 1)
                {
                    Console.WriteLine("\nBooked Tee Times:");
                    int count = 1;
                    foreach (BookedTeeTime teeTime in BookedTeeTimes)
                    {
                        Console.WriteLine(count + ". " + teeTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt") + " Customer: " + teeTime.User.FullName + " " + teeTime.User.Email + " " + teeTime.User.PhoneNumber);
                        count++;
                    }
                }
                else if (sortChoice == 2)
                {
                    LinkedList<BookedTeeTime> desc = new LinkedList<BookedTeeTime>();
                    for (int i = BookedTeeTimes.Count - 1; i >= 0; i--)
                    {
                        desc.AddLast(BookedTeeTimes.ElementAt(i));
                    }
                    BookedTeeTimes = desc;
                    Console.WriteLine("\nBooked Tee Times:");
                    int count = 1;
                    foreach (BookedTeeTime teeTime in BookedTeeTimes)
                    {
                        Console.WriteLine(count + ". " + teeTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt") + " Customer: " + teeTime.User.FullName + " " + teeTime.User.Email + " " + teeTime.User.PhoneNumber);
                        count++;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option. Please select 1 or 2");
                    ViewBookedTeeTimes();
                }
            }
            else
            {
                Console.WriteLine("Invalid option. Please select 1 or 2");
                ViewBookedTeeTimes();
            }
        }

        // Books a tee time by adding the user and selected time to the file and removing the slot from available times
        public DateTime BookTeeTime(OpenTeeTime selectedOpenTime, User user, string BookedTeeTimesFilePath)
        {
            DateTime time = selectedOpenTime.DateTime;
            string nullBookedTeeTime2 = "1/1/0001 12:00:00 AM";
            BookedTeeTime booked = new BookedTeeTime(user);
            if (user.Email == null || user.FullName == null || user.PhoneNumber == null || nullBookedTeeTime2 == time.ToString())
            {
                throw new ApplicationException("Invalid data entered.");
            }
            using (StreamWriter writer = new StreamWriter(BookedTeeTimesFilePath, true))
            {
                writer.WriteLine(user.FullName + "," + user.PhoneNumber + "," + user.Email + "," + selectedOpenTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt"));
            }

            BookedTeeTimes.Clear();
            BookedTeeTimes = GetBookedTeeTimes(BookedTeeTimesFilePath);
            string openTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
            openTeeTimeAccessor.RemoveOpenTeeTime(selectedOpenTime, openTeeTimesFilePath);
            return selectedOpenTime.DateTime;
        }



        // Sorts the booked tee times based on date and time
        void SortBookedTeeTimes(LinkedList<BookedTeeTime> bookedTeeTimes)
        {
            try
            {
                List<BookedTeeTime> sortedList = BookedTeeTimes.ToList();
                sortedList.Sort((a, b) => DateTime.Compare(a.DateTime, b.DateTime));

                BookedTeeTimes.Clear();

                foreach (var teeTime in sortedList)
                {
                    BookedTeeTimes.AddLast(teeTime);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while sorting Booked Tee Times: " + ex.Message);
            }
        }

        // Removes a booked tee time from the file and updates the list of booked tee times
        public DateTime RemoveBookedTeeTime(BookedTeeTime selectedTime, string BookedTeeTimesFilePath)
        {
            DateTime time = selectedTime.DateTime;
            string nullBookedTeeTime2 = "1/1/0001 12:00:00 AM";

            if (File.Exists(BookedTeeTimesFilePath) && time.ToString() != nullBookedTeeTime2)
            {
                string[] lines = File.ReadAllLines(BookedTeeTimesFilePath);
                string lineToRemove = selectedTime.User.FullName + "," + selectedTime.User.PhoneNumber + "," + selectedTime.User.Email + "," + selectedTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt");
                File.WriteAllLines(BookedTeeTimesFilePath, lines.Where(x => x.Trim() != lineToRemove));
            }
            else if (File.Exists(BookedTeeTimesFilePath) && time.ToString() == nullBookedTeeTime2)
            {
                throw new ApplicationException("Invalid booked tee time");
            }
            else
            {
                throw new FileNotFoundException("Booked Tee Times file does not exist.");
            }
            BookedTeeTimes.Clear();
            BookedTeeTimes = GetBookedTeeTimes(BookedTeeTimesFilePath);
            return time;

        }

    }
}
