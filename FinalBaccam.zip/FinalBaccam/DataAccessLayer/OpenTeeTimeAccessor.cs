﻿using DataObjects;
using Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DataAccessLayer
{
    public class OpenTeeTimeAccessor : OpenTeeTimeIF
    {
        //protected string OpenTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";

        Queue<OpenTeeTime> OpenTeeTimes = new Queue<OpenTeeTime>();

        public OpenTeeTimeAccessor() { }

        // Retrieves open tee times from a file and returns a queue of OpenTeeTime objects from
        // the OpenTeeTimesList text file
        public Queue<OpenTeeTime> GetOpenTeeTimes(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string[] lines = File.ReadAllLines(filePath);
                    if (lines.Length > 0)
                    {
                        foreach (string line in lines)
                        {
                            DateTime t;
                            if (DateTime.TryParseExact(line, "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out t))
                            {
                                OpenTeeTime teeTime = new OpenTeeTime(t);
                                OpenTeeTimes.Enqueue(teeTime);
                            }
                            else
                            {
                                Console.WriteLine("Invalid date format found in the file.");
                            }
                        }
                    }
                    else 
                    {
                        Console.WriteLine("There are currently no open tee times.");
                        return null;
                    }
                }
                else
                {
                    throw new FileNotFoundException("Open Tee Times file does not exist.");
                }
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Could not find the Open Tee Times file.");
            }
            return OpenTeeTimes;
        }

        // Displays the open tee times based on the selected sorting order
        public void ViewOpenTeeTimes()
        {

            string OpenTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
            OpenTeeTimes.Clear();
                GetOpenTeeTimes(OpenTeeTimesFilePath);
                SortOpenTeeTimes(OpenTeeTimes);

                Console.WriteLine("\nChoose sorting order:");
                Console.WriteLine("1. Earliest to Latest");
                Console.WriteLine("2. Latest to Earliest");
                Console.Write("Select an option: ");

                if (int.TryParse(Console.ReadLine(), out int sortChoice))
                {
                    if (sortChoice == 1)
                    {
                        Console.WriteLine("\nOpen Tee Times:");
                        int count = 1;
                        foreach (OpenTeeTime teeTime in OpenTeeTimes)
                        {
                            Console.WriteLine(count + ". " + teeTime.DateTime.ToString("MM/dd/yyyy hh:mm tt"));
                            count++;
                        }
                    }
                    else if (sortChoice == 2)
                    {
                        List<OpenTeeTime> sorted = OpenTeeTimes.ToList();
                        OpenTeeTimes.Clear();
                        for (int i = sorted.Count - 1; i >= 0; i--)
                        {
                            OpenTeeTimes.Enqueue(sorted.ElementAt(i));
                        }
                        Console.WriteLine("\nOpen Tee Times:");
                        int count = 1;
                        foreach (OpenTeeTime teeTime in OpenTeeTimes)
                        {
                            Console.WriteLine(count + ". " + teeTime.DateTime.ToString("MM/dd/yyyy hh:mm tt"));
                            count++;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid option. Please select 1 or 2");
                        ViewOpenTeeTimes();
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option. Please select 1 or 2");
                    ViewOpenTeeTimes();
                }

  

        }

        // Allows selection of an open tee time from the displayed list
        public OpenTeeTime SelectOpenTeeTime(string filePath)
        {
            try
            {
                OpenTeeTime selected = new OpenTeeTime();
                ViewOpenTeeTimes();
                Console.WriteLine("Select Open Tee Time:");

                if (int.TryParse(Console.ReadLine(), out int teeTimeNum))
                {
                    if (teeTimeNum > 0 && teeTimeNum <= OpenTeeTimes.Count)
                    {
                        selected = OpenTeeTimes.ElementAt(teeTimeNum - 1);
                    }
                    else
                    {
                        Console.WriteLine("Invalid selection. Please enter a valid number.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter one of the provided numbers.");
                }
                return selected;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while selecting Open Tee Time: " + ex.Message);
                return null;
            }
        }

        // Removes an open tee time from the file and updates the list of open tee times
        public int RemoveOpenTeeTime(OpenTeeTime selectedTime, string filePath)
        {
            try
            {
                string lineToRemove = selectedTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt");
                if (File.Exists(filePath) && lineToRemove != "01/01/0001 12:00:00 AM")
                {
                    string[] lines = File.ReadAllLines(filePath);
                    File.WriteAllLines(filePath, lines.Where(line => line.Trim() != lineToRemove));

                    OpenTeeTimes.Clear();
                    OpenTeeTimes = GetOpenTeeTimes(filePath);
                    return 1;
                }
                else if (File.Exists(filePath) && lineToRemove == "01/01/0001 12:00:00 AM") 
                {
                    throw new ApplicationException("Invalid selected date.");

                }
                else
                {
                    throw new FileNotFoundException("Open Tee Times file does not exist.");
                }
                return 0;
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Could not find the Open Tee Times file.");
            }
        }

        // Adds an open tee time to the OpenTeeTimesList file and returns a string representation of the added tee time
        public string AddOpenTeeTime(OpenTeeTime openTeeTime, string filePath)
        {
            string lineToRemove = openTeeTime.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt");
            if (lineToRemove == "01/01/0001 12:00:00 AM") 
            {
                throw new ApplicationException("Invalid tee time");
            }
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(openTeeTime);
                }
            }
            catch 
            {
                throw new FileNotFoundException("File not found.");
            }
            return openTeeTime.ToString();
        }

        // Sorts the open tee times based on date and time
        static void SortOpenTeeTimes(Queue<OpenTeeTime> openTeeTimes)
        {
            try
            {
                List<OpenTeeTime> sortedList = openTeeTimes.ToList();
                sortedList.Sort((a, b) => DateTime.Compare(a.DateTime, b.DateTime));

                openTeeTimes.Clear();

                foreach (var teeTime in sortedList)
                {
                    openTeeTimes.Enqueue(teeTime);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while sorting Open Tee Times: " + ex.Message);
            }
        }
    }
}
