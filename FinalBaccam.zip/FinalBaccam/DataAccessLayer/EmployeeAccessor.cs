﻿using DataObjects;
using Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class EmployeeAccessor : EmployeeIF
    {
        OpenTeeTimeAccessor openTeeTimeAccessor = new OpenTeeTimeAccessor();
        BookedTeeTimeAccessor bookedTeeTimeAccessor = new BookedTeeTimeAccessor();
        UserAccessor userAccessor = new UserAccessor();
        Validater helper = new Validater();

        // Displays an admin menu and allows administrative actions based on user input
        public void StartAdminMenu(Employee employee)
        {
            string BookedTeeTimesFilePath = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/BookedTeeTimesQueue.txt";
            string OpenTeeTimesFilePath = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";


            Console.WriteLine("Welcome to the Tee Time Scheduler!");
            bool go = true;
            while (go)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. View Open Tee Times");
                Console.WriteLine("2. View Booked Tee Times");
                Console.WriteLine("3. Book Tee Time");
                Console.WriteLine("4. Delete Booked Tee Time");
                Console.WriteLine("5. Add Open Tee Time");
                Console.WriteLine("6. Delete Open Tee Time");
                Console.WriteLine("7. Log out");
                Console.Write("Select an option: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    if (choice == 1)
                    {
                        openTeeTimeAccessor.ViewOpenTeeTimes();
                    }
                    else if (choice == 2)
                    {
                        bookedTeeTimeAccessor.ViewBookedTeeTimes();
                    }
                    else if (choice == 3)
                    {
                        OpenTeeTime selected = openTeeTimeAccessor.SelectOpenTeeTime(OpenTeeTimesFilePath);
                        AdminBookTeeTime(employee, selected, BookedTeeTimesFilePath);
                    }
                    else if (choice == 4) 
                    {
                        BookedTeeTime selected = bookedTeeTimeAccessor.SelectBookedTeeTime(BookedTeeTimesFilePath);
                        AdminDeleteBookedTeeTime(employee, selected, BookedTeeTimesFilePath);
                    }
                    else if (choice == 5)
                    {
                        bool validInput = false;
                        while (!validInput)
                        {
                            Console.WriteLine("Please enter a future date time in the format: MM/DD/YYYY HH:MM:SS AM/PM");
                            string timeStr = Console.ReadLine();
                            DateTime time;

                            if (DateTime.TryParseExact(timeStr, "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out time))
                            {
                                OpenTeeTime selected = new OpenTeeTime(time);
                                AdminAddOpenTeeTime(employee, selected, OpenTeeTimesFilePath);
                                validInput = true;
                            } 
                            
                            else
                            {
                                Console.WriteLine("Invalid date time. Please try again.");
                            }
                        }
                    }
                    else if (choice == 6)
                    {
                        OpenTeeTime selected = openTeeTimeAccessor.SelectOpenTeeTime(OpenTeeTimesFilePath);
                        AdminDeleteOpenTeeTime(employee, selected, OpenTeeTimesFilePath);
                    }
                    else if (choice == 7)
                    {
                        Console.WriteLine("Goodbye!");
                        go = false;
                    }
                    else
                    {
                        Console.WriteLine("Please choose an option 1 - 7 using only digits.");
                        StartAdminMenu(employee);
                    }
                }
                else
                {
                    Console.WriteLine("Please choose an option 1 - 7 using only digits.");
                    StartAdminMenu(employee);
                }
            }
        }

        // Attempts to sign in an administrator using provided credentials
        public Employee AdminSignOn(string employeeID, string password, string filePath)
        {
            try
            {
                LinkedList<Employee> employees = GetEmployees(filePath);
                foreach (Employee emp in employees) 
                {
                    emp.EmployeeID.ToString();
                    if (emp.EmployeeID.ToString() == employeeID && emp.Password.ToString() == password)
                    {
                        return emp;
                    } 
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
                return null;
            }
        }

        // Books a tee time with administrative privileges and logs the transaction in a text file
        public void AdminBookTeeTime(Employee employee, OpenTeeTime selected, string filePath)
        {
            try
            {
                User customer = userAccessor.CreateUser();

                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(customer.FullName + "," + customer.PhoneNumber + "," + customer.Email + "," + selected.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt"));
                }

                string transaction = "Transaction: Booked Tee Time, Customer: " + customer.FullName + ", " + customer.PhoneNumber + ", " + customer.Email + ", DateTime: " + selected.DateTime;
                CreateEmployeeTransaction(employee, transaction);

                string openTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
                openTeeTimeAccessor.RemoveOpenTeeTime(selected, openTeeTimesFilePath);

            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while booking Tee Time: " + ex.Message);
            }
        }

        // Deletes a booked tee time with administrative privileges and logs the transaction in a text file
        // while updating the OpenTeeTimes Queue
        public void AdminDeleteBookedTeeTime(Employee employee, BookedTeeTime selected, string filePath)
        {
            bookedTeeTimeAccessor.RemoveBookedTeeTime(selected, filePath);
            string transaction = "Transaction: Delete Booked Tee Time, Customer: " + selected.User.FullName + ", " + selected.User.PhoneNumber + ", " + selected.User.Email + ", DateTime: " + selected.DateTime;
            CreateEmployeeTransaction(employee, transaction);
        }

        // Adds an open tee time slot with administrative privileges and logs the transaction in a text file
        // and updates the BookedTeeTimes Queue
        public void AdminAddOpenTeeTime(Employee employee, OpenTeeTime selected, string filePath)
        {
            string dateStr = selected.DateTime.ToString("MM/dd/yyyy hh:mm:ss tt");
            if (employee.FullName == null || employee.EmployeeID == null|| dateStr == "01/01/0001 12:00:00 AM") 
            {
                throw new ApplicationException("Invalid data");
            }
            openTeeTimeAccessor.AddOpenTeeTime(selected, filePath);
            string transaction = "Added Open Tee Time: " + selected.DateTime.ToString();
            CreateEmployeeTransaction(employee, transaction);
        }

        // Deletes an open tee time slot with administrative privileges and logs the transaction in a text file
        // and updates the OpenTeeTimes Queue
        public void AdminDeleteOpenTeeTime(Employee employee, OpenTeeTime selected, string filePath)
        {
            openTeeTimeAccessor.RemoveOpenTeeTime(selected, filePath);

            string transaction = "Removed Open Tee Time: " + selected.ToString();
            CreateEmployeeTransaction(employee, transaction);
        }

        // Creates a log of an employee's transaction for administrative actions
        public void CreateEmployeeTransaction(Employee employee, string transaction)
        {
            string EmployeeTransactionsListPath = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/EmployeeTransactions.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(EmployeeTransactionsListPath, true))
                {
                    writer.WriteLine(employee.EmployeeID + ", " + employee.FullName + ", " + transaction);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while creating employee transaction: " + ex.Message);
            }
        }
        // Retrieves a list of employees from a text file
        public LinkedList<Employee> GetEmployees(string filePath)
        {
            LinkedList<Employee> employees = new LinkedList<Employee>();
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                if (File.Exists(filePath) && lines.Length > 0)
                {
                    
                    foreach (string line in lines)
                    {
                        Employee employee = new Employee();
                        string[] data = line.Split(',');
                        if (data[2] == "Root")
                        {
                            employee.EmployeeID = data[0];
                            employee.Password = data[1];
                            employee.FullName = data[2];
                        }
                        else
                        {
                            employee.EmployeeID = data[0];
                            employee.Password = data[1];
                            employee.FullName = data[2];
                            employee.PhoneNumber = data[3];
                            employee.Email = data[4];
                        }
                        employees.AddLast(employee);
                        
                    }
                }
                return employees;
            }catch
            {
                throw new FileNotFoundException("File not found.");
            }
        }

    }
}
