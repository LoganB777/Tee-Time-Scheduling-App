﻿using DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class UserAccessor
    {
        Validater validater = new Validater();

        // Creates a User object using user input prompted to the user and returns the
        // User object while at the same time validating the data
        public User CreateUser() 
        {
            User user = new User();
            while (true)
            {
                Console.WriteLine("Please enter a full name:");
                string fullName = Console.ReadLine();
                if (validater.ValidateFullName(fullName))
                {
                    user.FullName = fullName;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Name. Please try again.");
                }
            }

            while (true)
            {
                Console.WriteLine("Please enter a phone number:");
                string phone = Console.ReadLine();
                if (validater.ValidatePhoneNumber(phone))
                {
                    user.PhoneNumber = phone;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid phone number. Please try again.");
                }
            }

            while (true)
            {
                Console.WriteLine("Please enter an email:");
                string email = Console.ReadLine();
                if (validater.ValidateEmail(email))
                {
                    user.Email = email;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid email address. Please try again.");
                }
            }
            return user;
        }
            
        
    }
}
