﻿using DataAccessLayer;
using DataObjects;
using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace LogicLayer
{
    public class Helper
    {
        BookedTeeTimeAccessor bookedTeeTimeAccessor = new BookedTeeTimeAccessor();
        OpenTeeTimeAccessor openTeeTimeAccessor = new OpenTeeTimeAccessor();
        EmployeeAccessor employeeAccessor = new EmployeeAccessor();
        UserAccessor userAccessor = new UserAccessor();
        public void MainMenu()
        {

            string OpenTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
            string BookedTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/BookedTeeTimesQueue.txt";
            string EmployeesListPath = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/AdminUsersList.txt";

            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. View Open Tee Times");
                Console.WriteLine("2. Book a Tee Time");
                Console.WriteLine("3. Admin Sign On");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    if (choice == 1)
                    {
                        openTeeTimeAccessor.ViewOpenTeeTimes();
                    }
                    else if (choice == 2)
                    {
                        OpenTeeTime openTeeTime = openTeeTimeAccessor.SelectOpenTeeTime(OpenTeeTimesFilePath);
                        User user = userAccessor.CreateUser();
                        bookedTeeTimeAccessor.BookTeeTime(openTeeTime, user, BookedTeeTimesFilePath);
                        Console.WriteLine("\nA tee time has been scheduled for: " + openTeeTime.DateTime + "\nPlease check your email for more details.");
                    }
                    else if (choice == 3)
                    {
                        Console.WriteLine("Please enter your employeeID:");
                        string id = Console.ReadLine();
                        Console.WriteLine("Please enter your password:");
                        string password = Console.ReadLine();

                        Employee employee = employeeAccessor.AdminSignOn(id, password, EmployeesListPath);
                        if (employee == null)
                        {
                            Console.WriteLine("Incorrect employeeID or password.");
                            MainMenu();
                        }
                        else
                        {
                            employeeAccessor.StartAdminMenu(employee);
                        }
                    }
                    else if (choice == 4)
                    {
                        Console.WriteLine("GoodBye!");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Please only use numbers 1-4 from the menu.");
                        MainMenu();
                    }
                }
                else
                {
                    Console.WriteLine("Please only use numbers 1-4 from the menu.");
                    MainMenu();
                }
            }

        }

    }
}

