﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DataObjects;

namespace DataAccessLayer.Tests
{
    [TestClass()]
    public class EmployeeAccessorTests
    {
        string employeesFile = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/AdminUsersList.txt";
        string openTeeTimesFile = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
        EmployeeAccessor employeeAccessor = new EmployeeAccessor();
        OpenTeeTimeAccessor openTeeTimeAccessor = new OpenTeeTimeAccessor();

        [ExpectedException(typeof(FileNotFoundException))]
        [TestMethod()]
        public void GetEmployeesTestThrowsExceptionWithBadPath()
        {
            LinkedList<Employee> employees = employeeAccessor.GetEmployees("bad");
        }

        [TestMethod()]
        public void GetEmployeesReturnsEmployees()
        {
            //arange
            int none = 0;
            // act
            LinkedList<Employee> employees = employeeAccessor.GetEmployees(employeesFile);
            // assert
            Assert.IsTrue(employees.Count > 0);
        }

        // not testing bad data because that is being validated and wont fail, the user will
        // just keep being prompted for correct data else where in the program
        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void AddOpenTeeTimeThrowsExceptionWithBadEmployee()
        {
            // arrange
            User user = new User();
            OpenTeeTime ott =new OpenTeeTime(DateTime.ParseExact("12/21/2023 10:23:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));
            Employee employee = new Employee(user);

            // assert
            employeeAccessor.AdminAddOpenTeeTime(employee, ott, openTeeTimesFile);
        }

        // not testing bad data because that is being validated and wont fail, the user will
        // just keep being prompted for correct data else where in the program
        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void AddOpenTeeTimeThrowsExceptionWithBadOpenTeeTime()
        {
            // arrange
            User user = new User("user", "6417878787", "myemail@gmail.com");
            OpenTeeTime ott = new OpenTeeTime();
            Employee employee = new Employee(user);

            // assert
            employeeAccessor.AdminAddOpenTeeTime(employee, ott, openTeeTimesFile);
        }

        [TestMethod()]
        public void AddOpenTeeTimePasses()
        {
            //arrange
            User user = new User("user", "6417878787", "myemail@gmail.com");
            OpenTeeTime ott = new OpenTeeTime(DateTime.ParseExact("12/21/2023 10:23:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));
            Employee employee = new Employee(user);
            employee.EmployeeID = "7000000010";
            Queue<OpenTeeTime> otts = openTeeTimeAccessor.GetOpenTeeTimes(openTeeTimesFile);
            int beforeAdd = otts.Count;
            int after = 0;

            // acct
            employeeAccessor.AdminAddOpenTeeTime(employee, ott, openTeeTimesFile);
            otts = openTeeTimeAccessor.GetOpenTeeTimes(openTeeTimesFile);
            after = otts.Count;
            //assert
            Assert.IsTrue(after > beforeAdd);
        }

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        // not testing bad data because that is being validated and wont fail, the user will
        // just keep being prompted for correct data else where in the program
        public void AddBookedTeeTimeThrowsExceptionWithBadOpenTeeTime()
        {
            // arrange
            User user = new User("user", "6417878787", "myemail@gmail.com");
            OpenTeeTime ott = new OpenTeeTime();
            Employee employee = new Employee(user);

            // assert
            employeeAccessor.AdminBookTeeTime(employee, ott, openTeeTimesFile);
        }


    }
}