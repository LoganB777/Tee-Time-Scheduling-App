﻿using DataAccessLayer;
using DataObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;

namespace DataAccessLayer.Tests
{
    [TestClass()]
    public class OpenTeeTimeAccessorTests
    {
        OpenTeeTimeAccessor openTeeTimeAccessor = new OpenTeeTimeAccessor();
        string OpenTeeTimesFile = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/OpenTeeTimesList.txt";
        //private EmployeeAccessor employeeAccessor = new EmployeeAccessor();
        //string EmployeesFile = "C:/Users/logan/OneDrive/Desktop/FinalBaccam/DataAccessLayerTests/AdminUsersList.txt";


        [ExpectedException(typeof(FileNotFoundException))]
        [TestMethod()]
        public void AssertGetOpenTeeTimesTestThrowsFileNotFoundException()
        {
            //arange
            string badPath = "wrongFilePath";
            //act
            openTeeTimeAccessor.GetOpenTeeTimes(badPath);
        }
        [TestMethod()]
        public void GetOpenTeeTimesTestReturnsOpenTeeTimes()
        {
            //arrange
            int none = 0;
            Queue<OpenTeeTime> openTees = new Queue<OpenTeeTime>();
            //act
            openTees = openTeeTimeAccessor.GetOpenTeeTimes(OpenTeeTimesFile);
            //assert
            Assert.IsTrue(openTees.Count > none);
        }

        [TestMethod()]
        //This method will not fail with invalid user input, it just continually loops
        //until the user enters correct data
        public void SelecteOpenTeeTimePasses()
        {
            // arrange
            OpenTeeTime openTeeTime = new OpenTeeTime();
            // act
            var reader = new StringReader("1");
            Console.SetIn(reader);
            openTeeTimeAccessor.SelectOpenTeeTime(OpenTeeTimesFile);
            // assert
            Assert.IsTrue(openTeeTime != null);
        }

        //[TestMethod()]
        //public void RemoveOpenTeeTimePasses()
        //{
        //    // arrange
        //    int expected = 1;

        //    // Set up the first input stream
        //    var reader = new StringReader("1");
        //    Console.SetIn(reader);
            

        //    // act
        //    // Set up the second input stream using reader2
        //    var reader2 = new StringReader("1");
        //    Console.SetIn(reader2); // Use reader2 here
        //    OpenTeeTime ott = openTeeTimeAccessor.SelectOpenTeeTime(OpenTeeTimesFile);
        //    int actual = openTeeTimeAccessor.RemoveOpenTeeTime(ott, OpenTeeTimesFile);

        //    // assert
        //    Assert.AreEqual(actual, expected);
        //}

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void RemoveOpenTeeTimeThrowsExceptionWithNullTeeTime()
        {
            //arrange
            OpenTeeTime teeTime = new OpenTeeTime();
            //act
            openTeeTimeAccessor.RemoveOpenTeeTime(teeTime, OpenTeeTimesFile);
        }

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void AddOpenTeeTimeFailsWithNullTeeTime()
        {
            //arrange
            OpenTeeTime teeTime = new OpenTeeTime();
            //act
            openTeeTimeAccessor.AddOpenTeeTime(teeTime, OpenTeeTimesFile);
        }

        //This method will not fail with invalid user input, it just continually loops
        //until the user enters correct data
        [TestMethod()]
        public void AddOpenTeeTimesPasses() 
        {
            // arrange
            string expected = "12/20/2023 10:23:00 AM";
            OpenTeeTime ott = new OpenTeeTime(DateTime.ParseExact(expected, "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));

            // act & assert
            Assert.AreEqual(openTeeTimeAccessor.AddOpenTeeTime(ott, OpenTeeTimesFile), expected);
        }

        [TestMethod()]
        public void RemoveOpenTeeTimeFailsWithNullValue()
        {
            // Arrange
            BookedTeeTime tt = new BookedTeeTime();
            DateTime t = DateTime.ParseExact("10/01/2024 12:00:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture);
            tt.DateTime = t;

            // Act & Assert
            Assert.ThrowsException<FileNotFoundException>(() =>
            {
                int result = openTeeTimeAccessor.RemoveOpenTeeTime(tt, "badoath");
            });
        }
    }
}