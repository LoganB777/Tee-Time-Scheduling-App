﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DataObjects;

namespace DataAccessLayer.Tests
{
    [TestClass()]
    public class BookedTeeTimesAccessorTests
    {
        string BookedTeeTimesFilePath = "C://Users/logan/OneDrive/Desktop/FinalBaccam/DB/BookedTeeTimesQueue.txt";
        BookedTeeTimeAccessor bookedTeeTimeAccessor = new BookedTeeTimeAccessor();


        [TestMethod()]
        public void GetBookedTeeTimesPasses()
        {
            // arrange
            int none = 0;
            LinkedList<BookedTeeTime> bookedTeeTimes;

            // act
            bookedTeeTimes = bookedTeeTimeAccessor.GetBookedTeeTimes(BookedTeeTimesFilePath);
            int count = bookedTeeTimes.Count;

            //assert
            Assert.IsTrue(count > none);
        }

        //This method will not fail with invalid user input, it just continually loops
        //until the user enters correct data
        [TestMethod()]
        public void SelectBookedTeeTimePasses()
        {
            // arrange
            BookedTeeTime btt = new BookedTeeTime();
            // act
            var reader = new StringReader("1");
            Console.SetIn(reader);
            bookedTeeTimeAccessor.SelectBookedTeeTime(BookedTeeTimesFilePath);
            // assert
            Assert.IsTrue(btt != null);

        }

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void RemoveBookedTeeTimeFailsWithNull()
        {
            // arrange
            BookedTeeTime btt = new BookedTeeTime();
            //act
            bookedTeeTimeAccessor.RemoveBookedTeeTime(btt, BookedTeeTimesFilePath);
        }

        [TestMethod()]
        public void RemoveBookedTeeTimePasses()
        {
            // arrange
            User user = new User("name", "6417845789", "myemail@email.com");
            OpenTeeTime time =new OpenTeeTime(DateTime.ParseExact("12/07/2023 10:23:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));
            BookedTeeTime btt = new BookedTeeTime(user);
            btt.DateTime = time.DateTime;
            // act
            bookedTeeTimeAccessor.BookTeeTime(time,user, BookedTeeTimesFilePath);
            DateTime actual = bookedTeeTimeAccessor.RemoveBookedTeeTime(btt, BookedTeeTimesFilePath);
            Assert.AreEqual(btt.DateTime, actual);
        }

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void BookTeeTimeThrowsExceptionWithNullUserData() 
        {
            // arrange
            User user = new User();
            OpenTeeTime time = new OpenTeeTime(DateTime.ParseExact("12/07/2023 10:23:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));
            BookedTeeTime btt = new BookedTeeTime(user);
            btt.DateTime = time.DateTime;
            // act
            bookedTeeTimeAccessor.BookTeeTime(btt, user, BookedTeeTimesFilePath);
        }
        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void BookTeeTimeThrowsExceptionWithNullTeeTime()
        {
            // arrange
            User user = new User("name", "6417845789", "myemail@email.com");
            OpenTeeTime time = new OpenTeeTime();
            BookedTeeTime btt = new BookedTeeTime(user);
            btt.DateTime = time.DateTime;
            // act
            bookedTeeTimeAccessor.BookTeeTime(btt, user, BookedTeeTimesFilePath);
        }

        [TestMethod()]
        public void BookTeeTimePasses()
        {
            // arrange
            User user = new User("name", "6417845789", "myemail@email.com");
            OpenTeeTime time = new OpenTeeTime(DateTime.ParseExact("12/07/2023 10:23:00 AM", "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture));
            BookedTeeTime btt = new BookedTeeTime(user);
            btt.DateTime = time.DateTime;
            // act
            DateTime act = bookedTeeTimeAccessor.BookTeeTime(btt, user, BookedTeeTimesFilePath);
            // assert
            Assert.AreEqual(act, time.DateTime);

        }
    }
}