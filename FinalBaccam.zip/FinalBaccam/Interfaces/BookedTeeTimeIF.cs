﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;

namespace Interfaces
{
    public interface BookedTeeTimeIF
    {
        LinkedList<BookedTeeTime> GetBookedTeeTimes(string BookedTeeTimesFilePath);
        public void ViewBookedTeeTimes();
        public DateTime BookTeeTime(OpenTeeTime openTeeTime, User user, string filePath);
        public DateTime RemoveBookedTeeTime(BookedTeeTime selected, string filePath);
        public BookedTeeTime SelectBookedTeeTime(string filePath);
    }
}
