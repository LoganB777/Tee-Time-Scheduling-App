﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
namespace Interfaces
{
    public interface OpenTeeTimeIF
    {
        public Queue<OpenTeeTime> GetOpenTeeTimes(string filePath);
        public void ViewOpenTeeTimes();
        public string AddOpenTeeTime(OpenTeeTime openTeeTime, string filePath);
        public int RemoveOpenTeeTime(OpenTeeTime selectedTime, string filePath);
        public OpenTeeTime SelectOpenTeeTime(string filePath);
    }
}
