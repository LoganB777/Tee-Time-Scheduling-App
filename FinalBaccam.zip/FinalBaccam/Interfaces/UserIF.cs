﻿using System;

namespace Interfaces
{
    public interface UserIF
    {
        public string GetUserIDByEmail();
        public string GetNameByUserID();
    }
}
