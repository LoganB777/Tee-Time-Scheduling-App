﻿using DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public interface EmployeeIF
    {
        public Employee AdminSignOn(string employeeID, string password, string filePath);
        public void AdminBookTeeTime(Employee employee, OpenTeeTime selected, string filePath);
        public void AdminDeleteBookedTeeTime(Employee employee, BookedTeeTime selected, string filePath);
        public void AdminAddOpenTeeTime(Employee employee, OpenTeeTime selected, string filePath);
        public void AdminDeleteOpenTeeTime(Employee employee, OpenTeeTime selected, string filePath);
        public void CreateEmployeeTransaction(Employee employee, string transaction);
    }
}
